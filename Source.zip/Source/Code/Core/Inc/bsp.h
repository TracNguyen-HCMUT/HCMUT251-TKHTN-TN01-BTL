#ifndef BSP_H
#define BSP_H

#include "stm32f1xx.h" // Thư viện CMSIS chuẩn

// --- ĐỊNH NGHĨA CHÂN (Theo Schematic_Docs.pdf) ---
// LCD Control (Port A)
#define LCD_CTRL_PORT   GPIOA
#define LCD_RS          (1 << 8)  // PA8
#define LCD_RW          (1 << 9)  // PA9
#define LCD_EN          (1 << 10) // PA10

// LCD Data (Port B)
#define LCD_DATA_PORT   GPIOB
#define LCD_D4          (1 << 12) // PB12
#define LCD_D5          (1 << 13) // PB13
#define LCD_D6          (1 << 14) // PB14
#define LCD_D7          (1 << 15) // PB15

// I2C2 Hardware (PB10, PB11)
#define I2C2_PORT       GPIOB
#define I2C2_SCL        (1 << 10)
#define I2C2_SDA        (1 << 11)

// Buttons & Switch (Port B)
#define BTN_PREV_DEC    (1 << 0)  // PB0
#define SW_MODE         (1 << 1)  // PB1
#define BTN_NEXT_INC    (1 << 2)  // PB2

// Output Indicators
#define LED_RED         (1 << 3)  // PB3
#define BUZZER_PIN      (1 << 15) // PA15 (Lưu ý: Chân JTAG)

// --- FUNCTION PROTOTYPES ---
void BSP_Init(void);           // Hàm khởi tạo tổng
void HAL_Delay(uint32_t ms);   // Hàm delay
uint32_t HAL_GetTick(void);    // Lấy thời gian hệ thống

// I2C2 Functions (Hardware Register)
void I2C2_Start(void);
void I2C2_Stop(void);
void I2C2_Write(uint8_t data);
uint8_t I2C2_Read(uint8_t ack);

#endif
