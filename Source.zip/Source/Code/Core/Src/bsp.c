#include "bsp.h"

// --- LƯU Ý QUAN TRỌNG ---
// Code đã được chỉnh sửa để chạy trên PROTEUS theo sơ đồ chân:
// 1. I2C: Chuyển từ I2C2 (PB10/PB11) sang I2C1 (PB6/PB7).
// 2. SysTick: Giữ nguyên cấu hình chuẩn HAL.

// Cấu hình SysTick để tạo ngắt 1ms
void BSP_SysTick_Init(void) {
    SysTick_Config(SystemCoreClock / 1000);
}

// 1. Cấu hình Clock (RCC Registers)
void BSP_SystemClock_Config(void) {
    // Bật HSE (High Speed External)
    RCC->CR |= RCC_CR_HSEON;
    while (!(RCC->CR & RCC_CR_HSERDY)); // Đợi thạch anh ổn định

    // Cấu hình Flash Latency (bắt buộc khi chạy 72MHz)
    FLASH->ACR |= FLASH_ACR_PRFTBE;
    FLASH->ACR &= ~FLASH_ACR_LATENCY;
    FLASH->ACR |= FLASH_ACR_LATENCY_2;

    // Cấu hình PLL: Nguồn HSE, Nhân 9 (8MHz * 9 = 72MHz)
    RCC->CFGR |= RCC_CFGR_PLLSRC;
    RCC->CFGR |= RCC_CFGR_PLLMULL9;

    // Cấu hình Bus Prescalers: AHB=1, APB1=/2 (36M max), APB2=1
    RCC->CFGR |= RCC_CFGR_PPRE1_DIV2;

    // Bật PLL
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));

    // Chọn PLL làm System Clock
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);

    // Cập nhật giá trị SystemCoreClock để dùng cho SysTick
    SystemCoreClock = 72000000;
}

// 2. Cấu hình GPIO (CRL, CRH Registers)
void BSP_GPIO_Init(void) {
    // Bật Clock cho Port A, B, C và AFIO
    RCC->APB2ENR |= (RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPBEN | RCC_APB2ENR_AFIOEN);

    // --- PA8, PA9, PA10 (LCD Control) -> Output Push-Pull 50MHz ---
    GPIOA->CRH &= 0xFFFFF000;
    GPIOA->CRH |= 0x00000333;

    // --- PB12, PB13, PB14, PB15 (LCD Data) -> Output Push-Pull 50MHz ---
    GPIOB->CRH &= 0x0000FFFF;
    GPIOB->CRH |= 0x33330000;

    // --- PB0, PB1, PB2 (Buttons/Switch) -> Input Pull-Up ---
    GPIOB->CRL &= 0xFFFFF000; // Clear PB0,1,2
    GPIOB->CRL |= 0x00000888;
    GPIOB->ODR |= (BTN_PREV_DEC | SW_MODE | BTN_NEXT_INC); // Pull-Up

    // --- PB3 (LED Red) -> Output Push-Pull ---
    GPIOB->CRL &= 0xFFFF0FFF;
    GPIOB->CRL |= 0x00003000;

    // --- PA15 (Buzzer) -> Output Push-Pull ---
    // Lưu ý: PA15 là chân JTAG, cần remap để dùng như GPIO
    AFIO->MAPR |= AFIO_MAPR_SWJ_CFG_JTAGDISABLE; // Tắt JTAG, giữ SWD
    GPIOA->CRH &= 0x0FFFFFFF;
    GPIOA->CRH |= 0x30000000;

    // --- CẤU HÌNH I2C1 (PB6, PB7) CHO PROTEUS ---
    // PB6 (SCL), PB7 (SDA) -> Alternate Function Open-Drain
    // Mode=11 (50MHz), CNF=11 (Alt Open-Drain) -> Hex: F
    GPIOB->CRL &= 0x00FFFFFF; // Clear PB6, PB7 (Bits 24-31)
    GPIOB->CRL |= 0xFF000000; // Set PB6, PB7 to Alt Open-Drain
}

// 3. Cấu hình Hardware I2C (I2C1 thay vì I2C2)
void BSP_I2C2_Init(void) { // Tên hàm giữ nguyên để tương thích main, nhưng ruột là I2C1
    // Bật Clock I2C1 (APB1)
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

    I2C1->CR1 |= I2C_CR1_SWRST; // Reset I2C1
    I2C1->CR1 &= ~I2C_CR1_SWRST;

    // Cấu hình Timing cho 100kHz (Standard Mode) tại PCLK1 = 36MHz
    I2C1->CR2 = 36;
    I2C1->CCR = 180;
    I2C1->TRISE = 37;

    I2C1->CR1 |= I2C_CR1_PE; // Enable Peripheral
}

// --- I2C Helper Functions (Dùng I2C1) ---
void I2C2_Start(void) {
    I2C1->CR1 |= I2C_CR1_START;
    while (!(I2C1->SR1 & I2C_SR1_SB)); // Đợi bit Start Generated
}

void I2C2_Stop(void) {
    I2C1->CR1 |= I2C_CR1_STOP;
}

void I2C2_Write(uint8_t data) {
    while (!(I2C1->SR1 & I2C_SR1_TXE)); // Đợi buffer trống
    I2C1->DR = data;
    while (!(I2C1->SR1 & I2C_SR1_BTF)); // Đợi Byte Transfer Finished
}

uint8_t I2C2_Read(uint8_t ack) {
    if (ack) I2C1->CR1 |= I2C_CR1_ACK;
    else I2C1->CR1 &= ~I2C_CR1_ACK;

    while (!(I2C1->SR1 & I2C_SR1_RXNE)); // Đợi data về
    return I2C1->DR;
}

// Thêm hàm khởi tạo chung để gọi ở Main
void BSP_Init(void) {
    BSP_SystemClock_Config();
    BSP_SysTick_Init();
    BSP_GPIO_Init();
    BSP_I2C2_Init();
}
