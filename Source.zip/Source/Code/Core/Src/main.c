#include "bsp.h"
#include <stdio.h>

// External Driver Functions
extern void LCD_Init(void);
extern void LCD_SetCursor(uint8_t row, uint8_t col);
extern void LCD_Print(char *str);
// THÊM DÒNG NÀY ĐỂ SỬA LỖI IMPLICIT DECLARATION
extern void LCD_Send(uint8_t val, uint8_t is_data);

extern void SHT31_Read(float *t, float *h);
extern float BH1750_Read(void);

// --- APP DATA ---
// Index: 0=TEMP, 1=HUMI, 2=LIGHT
float sensor_values[3] = {0.0f, 0.0f, 0.0f};
float thresholds[3]    = {35.0f, 80.0f, 500.0f}; // Default Thresholds
char *labels[3]        = {"Temp ", "Humi ", "Light"};
char *units[3]         = {"C", "%", "Lx"};

int current_page = 0; // 0, 1, 2
uint8_t mode_adjust = 0; // 0=View, 1=Adjust

// Helpers
uint8_t IsBtnPressed(uint32_t PIN) {
    if ((GPIOB->IDR & PIN) == 0) { // Active Low
        HAL_Delay(50); // Debounce
        if ((GPIOB->IDR & PIN) == 0) {
            while((GPIOB->IDR & PIN) == 0); // Wait Release
            return 1;
        }
    }
    return 0;
}

int main(void) {
    char buf[32]; // <--- TĂNG SIZE TỪ 16 LÊN 32 ĐỂ SỬA LỖI TRÀN
    uint32_t sensor_timer = 0;
    uint32_t lcd_timer = 0;

    BSP_Init();
    LCD_Init();

    LCD_Print("System Booting..");
    HAL_Delay(1000);
    LCD_Send(0x01, 0); // Clear (Giờ đã có extern, không lỗi nữa)

    while (1) {
        // --- 1. ĐỌC CẢM BIẾN (Mỗi 500ms) ---
        if (HAL_GetTick() - sensor_timer > 500) {
            float t, h, l;
            SHT31_Read(&t, &h);
            l = BH1750_Read();

            // Cập nhật mảng giá trị
            sensor_values[0] = t;
            sensor_values[1] = h;
            sensor_values[2] = l;

            // --- SAFETY: KIỂM TRA NGƯỠNG NỀN ---
            uint8_t alarm = 0;
            if (sensor_values[0] > thresholds[0]) alarm = 1; // Quá nhiệt

            if (alarm) {
                GPIOB->ODR |= LED_RED;   // Bật đèn
                GPIOA->ODR |= BUZZER_PIN; // Bật còi
            } else {
                GPIOB->ODR &= ~LED_RED;
                GPIOA->ODR &= ~BUZZER_PIN;
            }

            sensor_timer = HAL_GetTick();
        }

        // --- 2. KIỂM TRA MODE SW (PB1) ---
        // PB1 nối đất = SET (Adjust), Hở/VCC = VIEW
        if ((GPIOB->IDR & SW_MODE) == 0) {
            mode_adjust = 1;
        } else {
            mode_adjust = 0;
        }

        // --- 3. XỬ LÝ NÚT NHẤN ---
        if (mode_adjust == 0) {
            // === MODE VIEW ===
            // PB0 (PREV): Lùi trang
            if (IsBtnPressed(BTN_PREV_DEC)) {
                current_page--;
                if (current_page < 0) current_page = 2;
                LCD_Send(0x01, 0); // Xóa màn hình
            }
            // PB2 (NEXT): Tới trang
            if (IsBtnPressed(BTN_NEXT_INC)) {
                current_page++;
                if (current_page > 2) current_page = 0;
                LCD_Send(0x01, 0);
            }
        } else {
            // === MODE ADJUST ===
            // PB0 (DEC): Giảm Threshold
            if (IsBtnPressed(BTN_PREV_DEC)) {
                thresholds[current_page] -= (current_page == 2) ? 10.0f : 1.0f;
            }
            // PB2 (INC): Tăng Threshold
            if (IsBtnPressed(BTN_NEXT_INC)) {
                thresholds[current_page] += (current_page == 2) ? 10.0f : 1.0f;
            }
        }

        // --- 4. HIỂN THỊ LCD (Mỗi 200ms) ---
        if (HAL_GetTick() - lcd_timer > 200) {
            // Dòng 1: [Label]: [Giá trị] [Đơn vị]
            sprintf(buf, "%s: %4.1f %s   ", labels[current_page], sensor_values[current_page], units[current_page]);
            LCD_SetCursor(0, 0);
            LCD_Print(buf);

            // Dòng 2: Threshold: [Giá trị]
            char status_char = (mode_adjust) ? '*' : ' ';
            // Buf size 32 là đủ chứa chuỗi này
            sprintf(buf, "Thres%c: %4.1f    ", status_char, thresholds[current_page]);
            LCD_SetCursor(1, 0);
            LCD_Print(buf);

            lcd_timer = HAL_GetTick();
        }
    }
}
