#include "bsp.h"

// --- LCD PARALLEL 4-BIT DRIVER ---
void LCD_Pulse(void) {
    LCD_CTRL_PORT->ODR |= LCD_EN;
    HAL_Delay(1);
    LCD_CTRL_PORT->ODR &= ~LCD_EN;
    HAL_Delay(1);
}

void LCD_Write4Bit(uint8_t val) {
    // Xóa data cũ ở PB12-15
    LCD_DATA_PORT->ODR &= ~(0xF000);
    // Ghi data mới
    LCD_DATA_PORT->ODR |= ((val & 0x0F) << 12);
    LCD_Pulse();
}

// Hàm này cần được gọi ở Main, nên bỏ static (nếu có)
void LCD_Send(uint8_t val, uint8_t is_data) {
    if (is_data) LCD_CTRL_PORT->ODR |= LCD_RS;
    else LCD_CTRL_PORT->ODR &= ~LCD_RS;

    LCD_CTRL_PORT->ODR &= ~LCD_RW;

    LCD_Write4Bit(val >> 4); // 4 bit cao
    LCD_Write4Bit(val);      // 4 bit thấp
}

void LCD_Init(void) {
    HAL_Delay(50);
    LCD_CTRL_PORT->ODR &= ~LCD_RS;

    LCD_Write4Bit(0x03); HAL_Delay(5);
    LCD_Write4Bit(0x03); HAL_Delay(1);
    LCD_Write4Bit(0x03);
    LCD_Write4Bit(0x02); // 4-bit mode

    LCD_Send(0x28, 0); // 2 lines
    LCD_Send(0x0C, 0); // ON, No Cursor
    LCD_Send(0x06, 0); // Auto Inc
    LCD_Send(0x01, 0); // Clear
    HAL_Delay(2);
}

void LCD_SetCursor(uint8_t row, uint8_t col) {
    uint8_t addr = (row == 0) ? 0x80 : 0xC0;
    LCD_Send(addr | col, 0);
}

void LCD_Print(char *str) {
    while (*str) LCD_Send(*str++, 1);
}

// --- SENSORS DRIVER ---
#define SHT31_ADDR  0x44
#define BH1750_ADDR 0x23

void SHT31_Read(float *t, float *h) {
    I2C2_Start();
    I2C2_Write(SHT31_ADDR << 1);   // Write Addr
    I2C2_Write(0x24); I2C2_Write(0x00); // Cmd High Repeatability
    I2C2_Stop();

    HAL_Delay(20);

    I2C2_Start();
    I2C2_Write((SHT31_ADDR << 1) | 1); // Read Addr
    uint8_t d[6];
    for(int i=0; i<5; i++) d[i] = I2C2_Read(1);
    d[5] = I2C2_Read(0);
    I2C2_Stop();

    uint16_t tr = (d[0] << 8) | d[1];
    uint16_t hr = (d[3] << 8) | d[4];

    *t = -45.0f + (175.0f * tr / 65535.0f);
    *h = 100.0f * hr / 65535.0f;
}

float BH1750_Read(void) {
    I2C2_Start();
    I2C2_Write(BH1750_ADDR << 1);
    I2C2_Write(0x10); // Continuous High Res
    I2C2_Stop();

    // BH1750 cần ~120ms để đo, ta đọc luôn
    I2C2_Start();
    I2C2_Write((BH1750_ADDR << 1) | 1);
    uint8_t msb = I2C2_Read(1);
    uint8_t lsb = I2C2_Read(0);
    I2C2_Stop();

    return ((msb << 8) | lsb) / 1.2f;
} // <--- ĐẢM BẢO CÓ DẤU NGOẶC NÀY
